# Neon Rally Online

Spielserver für zwei Spieler. Einrichtung: [ONLINE-EINRICHTUNG.md](ONLINE-EINRICHTUNG.md).

Die Website bleibt auf Netlify; dieses Projekt wird als eigener Docker-/Node-Webdienst eingerichtet. Es wurde noch kein öffentlicher Server bereitgestellt.

Node.js 22+, pnpm 11.25.0. Installation: `pnpm install --frozen-lockfile --ignore-scripts`. Start: `node server.cjs`. Tests: `node online-server.test.cjs`.
