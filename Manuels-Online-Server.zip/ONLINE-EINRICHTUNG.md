# Online Rally bereitstellen

## Was fertig ist

Zwei Spieler können über Raumcode oder Einladungs-QR gegeneinander Neon Rally spielen. Der Server entscheidet über Bewegung, Treffer und Punkte. Raum, Bereitschaft, Countdown, Pause, Wiederverbinden und Revanche sind umgesetzt. Die übrigen Spiele und der lokale Zwei-Spieler-Modus bleiben bestehen.

**Noch nicht im Internet aktiv:** Es wurde kein Hostingdienst gebucht und kein Upload durchgeführt. Der neue Knopf zeigt bis zur Einrichtung eine verständliche Meldung.

## Variante A: bisherige Netlify-Website behalten

1. **Serverpaket verwenden:** `Manuels-Online-Server.zip` in einen eigenen Ordner entpacken. Diese Dateien gehören in ein separates GitHub-Projekt für den Server. Die bestehende Spiele-Website bleibt in ihrem bisherigen Projekt.
2. **Webdienst einrichten:** Bei einem Anbieter mit dauerhaftem Node.js-/Docker-Webdienst einen Dienst aus diesem Projekt erstellen. Render ist ein möglicher Anbieter; dort Docker als Laufzeit und nach Möglichkeit Frankfurt als Region wählen. Tarif, mögliche Kosten und Ruhezustand vor dem Bestätigen selbst prüfen. Das ist keine Netlify-Function und keine rein statische Website.
3. **Umgebungswerte setzen:** `PUBLIC_SITE_URL=https://calypso-games.netlify.app/`. Bei Render wird die eigene Serveradresse aus `RENDER_EXTERNAL_URL` übernommen. Bei einem anderen Anbieter zusätzlich `PUBLIC_SERVER_URL=https://DEINE-SERVERADRESSE/` setzen. Port 8080 ist voreingestellt; ein vom Anbieter gesetzter PORT-Wert hat Vorrang. Healthcheck: `/health`. Nur eine Serverinstanz verwenden; Räume liegen vorübergehend im Speicher dieser Instanz.
4. **Auf einen gesunden Dienst warten:** `/health` muss `{"ok":true,"protocol":1}` zurückgeben. Bei Tarifen mit Ruhezustand kann der erste Verbindungsversuch länger dauern; gegebenenfalls erneut versuchen. Neustarts schließen vorhandene Räume.
5. **HTML bequem verbinden:** Die lokale Datei `ONLINE-EINRICHTUNG.html` doppelklicken. Serveradresse eintragen, die aktuelle `index.html` auswählen und die vorbereitete Datei herunterladen. Diese Hilfe lädt nichts hoch und überträgt keine Daten.
6. **Neue index.html hochladen:** Die heruntergeladene Datei wie bisher in deinem bestehenden Website-Projekt ersetzen. Erst nach erfolgreichem Website-Deployment neu laden.
7. **Mit zwei Geräten testen:** „Online spielen“ → „Raum erstellen“, Code eingeben oder den Raum-QR scannen, beide „Bereit“. Auch Pause, Verbindung kurz trennen, erneut beitreten und Revanche ausprobieren. Unterschiedliche Netze sind für die abschließende Prüfung wichtig.

Bei späteren Quellcode-Builds die Serveradresse zusätzlich in `online-config.js` eintragen; sonst erzeugt build.py wieder eine HTML-Datei ohne konfigurierte Serveradresse. Zugangsschlüssel gehören nie in diese Datei. Der Client benötigt keine API-Schlüssel.

## Variante B: Website und Server zusammen

Der Server liefert auch die fertige index.html aus. Wenn die ganze Website auf die neue Serveradresse umzieht, PUBLIC_SITE_URL auf diese Adresse setzen. Die mitgelieferte HTML-Datei mit leerer serverUrl erkennt die Konfiguration über `/online-config.json`, sobald der Online-Modus geöffnet wird. Der bisherige allgemeine Website-QR und die Hostingtexte müssen bei einem solchen Umzug ebenfalls aktualisiert werden. Für den bestehenden Netlify-Auftritt ist Variante A vorgesehen.

## Grenzen und Datenschutz vor Veröffentlichung

- Der Raumserver speichert Räume und Partien im Arbeitsspeicher: maximal 30 Minuten, bei Verbindungsabbruch maximal weitere 30 Sekunden bis zum Schließen des Raums. Bewusstes Verlassen schließt den Raum sofort. Ein Serverneustart verwirft alle Räume.
- Eine zufällige Wiederverbindungskennung liegt vorübergehend im sessionStorage des jeweiligen Browser-Tabs. Sie steht weder im Einladungslink noch in den Nachrichten an den Mitspieler. Der Einladungslink enthält den Raumcode.
- Der Server verarbeitet die Verbindungs-IP, Eingaben und Spielzustände. Die Anwendung legt keine Spieler-Datenbank oder Nachrichtenprotokolle an. Der gewählte Hoster kann eigene Zugriffsprotokolle führen.
- **Vor dem öffentlichen Betrieb** tatsächlichen Serverhoster, Region, Auftragsverarbeitung und Protokoll-Aufbewahrung in den Datenschutzhinweisen ergänzen. Die mitgelieferten Texte beschreiben bereits den Online-Datenfluss; der noch nicht gewählte Anbieter ist ausdrücklich offen.
- Grenzen: 100 Räume, 200 Verbindungen, 2 Spieler pro Raum, 2 KB pro eingehender Nachricht. Spieler melden keine selbst berechneten Punkte. Hinter einem Proxy teilen Verbindungen bewusst die Anfrageratenbegrenzung; diese kleine Fassung ist für einen privaten Hub, nicht für beliebig viele gleichzeitige Spieler ausgelegt.
- Tastatur, Touch und ein Controller pro Gerät sind vorgesehen. Fokusverlust und Controller-Abbruch pausieren. Ein Mobilbrowser kann einen Hintergrund-Tab anhalten; nach 30 Sekunden kann deshalb ein neuer Raum erforderlich sein.

## Lokaler Entwicklungstest

Node.js 22 oder neuer und pnpm 11.25.0: `pnpm install --frozen-lockfile --ignore-scripts`, anschließend `node server.cjs`. Standardadresse: http://127.0.0.1:8080/. `node online-server.test.cjs` führt Raum- und echte WebSocket-Verbindungstests aus. `npm start` funktioniert ebenfalls nach Installation der Abhängigkeiten. Werte aus `.env.example` werden nicht automatisch geladen; sie werden im Hosting-Dashboard als Umgebungswerte gesetzt.

Nur im vollständigen Entwicklungsordner: `node online-ui.test.cjs` und `node online-setup.test.cjs` prüfen Oberfläche und Einrichtungshilfe. Die Oberfläche wird mit simuliertem DOM und echtem Canvas geprüft; das ersetzt keinen Browser- oder Gerätetest. Das Docker-Abbild wurde hier nicht gebaut, weil kein Docker verfügbar ist. Der Server wurde unter Node.js mit echten lokalen WebSocket-Verbindungen und mit Produktionskonfiguration geprüft.

## Technische Quellen

- [MDN: WebSocket](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)
- [Render: WebSockets](https://render.com/docs/websocket)
- [Render: Docker](https://render.com/docs/docker)
- [Render: automatische Umgebungsvariablen](https://render.com/docs/environment-variables#automatic-environment-variables)
- [ws: offizielle Bibliothek](https://github.com/websockets/ws)

Es wurde weder eine bestimmte Tarifverfügbarkeit noch kostenloser Dauerbetrieb zugesichert.
